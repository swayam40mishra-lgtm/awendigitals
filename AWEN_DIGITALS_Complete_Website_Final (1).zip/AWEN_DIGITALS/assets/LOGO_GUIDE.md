# AWEN DIGITALS — Logo files

- `assets/logo-primary.svg`: primary light-background logo with tagline; used in the website header/footer.
- `assets/logo-primary-dark.svg`: light wordmark version for dark backgrounds.
- `assets/logo-symbol.svg`: symbol-only version for profile images and compact placements.
- `assets/logo-text.svg`: text-only wordmark for minimal placements.
- `assets/logo-monochrome.svg`: one-colour version for documents and print.
- `assets/favicon.svg`: browser tab icon.

Keep the SVG files together with the website's `assets/` folder. SVGs stay sharp at different screen sizes.
The contact buttons need a real business WhatsApp number configured in `assets/config.js` before launch.
