(function(){
  const cfg=window.AWEN_CONFIG||{};
  const toggle=document.querySelector('.menu-toggle');
  const nav=document.querySelector('.nav-links');
  if(toggle&&nav){toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'×':'☰'});nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');toggle.textContent='☰'}))}
  document.querySelectorAll('[data-wa]').forEach(el=>{
    const message=el.getAttribute('data-message')||"Hi AWEN DIGITALS! I'd like to discuss a project.";
    const n=cfg.whatsappNumber||'';
    if(n&&n!=='REPLACE_WITH_BUSINESS_WHATSAPP_NUMBER'&&/^\d{10,15}$/.test(n)){el.href='https://wa.me/'+n+'?text='+encodeURIComponent(message);el.target='_blank';el.rel='noopener noreferrer'}
    else{el.href='contact.html';el.removeAttribute('target');el.title='Add the business WhatsApp number in assets/config.js before launch'}
  });
  document.querySelectorAll('[data-email]').forEach(el=>{if(cfg.email){el.href='mailto:'+cfg.email;el.textContent=cfg.email}else{el.href='contact.html';el.textContent='Set up business email'}})
  document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  const current=location.pathname.split('/').pop()||'index.html';
  document.querySelectorAll('.nav-links a').forEach(a=>{if(a.getAttribute('href')===current)a.classList.add('active')});
  const form=document.querySelector('#project-form');
  if(form)form.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(form);const msg=`Hi AWEN DIGITALS! I'd like to discuss a project.\nName: ${d.get('name')}\nBusiness: ${d.get('business')||'Not provided'}\nService: ${d.get('service')}\nBudget: ${d.get('budget')||'Not sure yet'}\nDetails: ${d.get('details')}`;const n=cfg.whatsappNumber||'';if(n&&n!=='REPLACE_WITH_BUSINESS_WHATSAPP_NUMBER'&&/^\d{10,15}$/.test(n)){window.open('https://wa.me/'+n+'?text='+encodeURIComponent(msg),'_blank','noopener')}else{const blob=new Blob([msg],{type:'text/plain'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='awen-project-enquiry.txt';a.click();URL.revokeObjectURL(url);alert('WhatsApp number is not configured yet. Your enquiry was downloaded as a text file. Add the number in assets/config.js to enable direct WhatsApp enquiries.')}});
})();
