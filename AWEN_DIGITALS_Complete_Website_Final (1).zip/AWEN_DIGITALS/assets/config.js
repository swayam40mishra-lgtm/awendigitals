/* Before launch, replace the placeholder below with AWEN's dedicated WhatsApp number.
   Use country code + number without +, spaces, or punctuation (India example: 919876543210). */
window.AWEN_CONFIG = {
  whatsappNumber: "REPLACE_WITH_BUSINESS_WHATSAPP_NUMBER",
  email: "",
  founder: "Swayam Mishra",
  brand: "AWEN DIGITALS"
};
